namespace mid_assignment_backend.Models
{
    public enum RequestStatus
    {
        Waiting = 0,
        Approved = 1,
        Rejected = 2,
    }
}
