namespace mid_assignment_backend.Models
{
    public enum Roll
    {
        //Super user
        Admin = 1,
        //Normal user
        User = 0,
    }
}
