using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mid_assignment_backend.Models
{
    public class BookBorrowingRequestDetails
    {
        [Required]
        public int RequestId { get; set; }
        [Required]
        public List<string> BookIds { get; set; }
    }
}