using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace mid_assignment_backend.Models
{
    public class BookBorrowingRequest
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RequestId { get; set; }
        [Required]
        public int RequestByUserId { get; set; }
        [Required, MaxLength(50)]
        public DateTime Date { get; set; }
        [Required, DefaultValue(RequestStatus.Waiting)]
        public RequestStatus Status { get; set; }
        [Required]
        public int ProcessedByUserId { get; set; }
    }
}